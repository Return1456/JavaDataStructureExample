package example10;

public class Trace {
int x;
int y;
int dir;

public Trace(int x,int y,int dir) {
	// TODO Auto-generated constructor stub
	this.x=x;
	this.y=y;
	this.dir=dir;
}
}
