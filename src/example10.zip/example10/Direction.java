package example10;

public class Direction {
//int dir;
int a;
int b;
public Direction(int a,int b) {
	// TODO Auto-generated constructor stub
	this.a=a;
	this.b=b;
//	this.dir=dir;
}
}
